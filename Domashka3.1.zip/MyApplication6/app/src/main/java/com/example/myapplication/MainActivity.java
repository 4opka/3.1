package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String COUNT_KEY = "count";
    private static final String TITLE_KEY = "title";
    private int mCount = 0;
    private TextView countTextView;
    private Button countButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        countTextView = findViewById(R.id.countTextView);
        countButton = findViewById(R.id.countButton);

        if (savedInstanceState != null) {
            mCount = savedInstanceState.getInt(COUNT_KEY);
            setTitle(savedInstanceState.getString(TITLE_KEY));
        }
        countTextView.setText(String.valueOf(mCount));

        countButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCount++;
                countTextView.setText(String.valueOf(mCount));
            }
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(COUNT_KEY, mCount);
        outState.putString(TITLE_KEY, getTitle().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        mCount = savedInstanceState.getInt(COUNT_KEY);
        countTextView.setText(String.valueOf(mCount));
    }
}